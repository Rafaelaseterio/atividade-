#include <stdio.h>

int main(void) {

int numero1, numero2;
printf("Digite os numeros:");
scanf("%d %d", &numero1, &numero2);

if (numero1 > numero2)
printf("O numero %d e maior que %d", numero1, numero2);

else if (numero2 > numero1)
printf("O numero %d e maior que %d", numero2, numero1);

  
return 0;
}